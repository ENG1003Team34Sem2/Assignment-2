var map;
var currentCoordsGoogle;
var record=0;
var currentMarker;
var trackButton= document.getElementById('track');
var saveButton=document.getElementById('save');
var clearButton=document.getElementById('clear');
var detailsLabel= document.getElementById('details');
var techLabel= document.getElementById('tech');    
var currentRoute=[];
var currentRouteGoogle=[];
var currentTime;
var timeTaken; //minutes
var path;
var instantTime;
var instantPosition=[];
var currentPosition;
var currentSpeed="Initializing";
var instantDistance=0;
var totalDistance;
var pathArray=[];
var startMarker;
var endMarker;
var avgSpeed;
var accuracy;
    
//Initialises the map
function initMap() {

    map = new google.maps.Map(document.getElementById('map'), {
    zoom: 18
  });
    
//Runs the track function every 1 second, this gave a good balance between updates and performance
setInterval(track,1000)


}

//The track function contains various sub functions each with a specific role. Please refer to each sub function for more detailed information
function track() {
    
    
    getCurrentPosition();
    
    checkAccuracy();
    
    setMarker();
    
    writePath();

    routeDistance();
    
    writeLabel();
    
}
  
    
 //Uses the navigators geolocation tool to get current position    
function getCurrentPosition() {
  
  var options = {
  enableHighAccuracy: true,
  maximumAge: 0
  };
    
  navigator.geolocation.getCurrentPosition(success,error,options);
}

//Error handler
function error(err) {
  console.warn('ERROR(' + err.code + '): ' + err.message);
};

//This function is passed to the geolocator if it was succesfully able to get current location
function success(position) {
    
    if (instantPosition.length<2){
        instantPosition.push(position)
    }
    else if (instantPosition.length>=2){
        instantPosition.shift();
        instantPosition.push(position);
        instantSpeed();
    } 
    
    //Gets the accuracy, current positon lat/lng and also uses the lat/lng to create a google latlng object which is used with markers and polylines
    accuracy=position.coords.accuracy;
    currentPosition=position;  
    currentCoordsGoogle=new google.maps.LatLng(position.coords.latitude, position.coords.longitude)

    //If recording is enabled then the current position is pushed into an array that keeps track of route
    if (record===1){
    currentRoute.push(currentPosition);
    currentRouteGoogle.push(currentCoordsGoogle) ;
    }
    
 //Centers map to current position
    map.panTo(currentCoordsGoogle);
    
}

//This function handles turning the track feature on/off
function toggleTrack() {
    
        //If tracking is on 
    if (record===1) {
            //Changes button text and makes button reappaer
        trackButton.innerHTML="Start Tracking";
        saveButton.style.visibility="visible";
        clearButton.style.visibility="visible";
        
        //Sets record to off
        record=0;
    }
    
    //If tracking is off
    else if (record===0) {
         
        // This code runs if the user is trying to re-enable track but there is a route already tracked
        if (currentRoute.length>0){
            //Prompts user to continue informing current route will be deleted
            var cont=window.confirm("All unsaved routes will be deleted. Do you wish to continue");
            
           //If user wishes to continue it deletes the tracked route and starts tracking
            if (cont== true){
                    clearRoute();
                    trackButton.innerHTML="Stop Tracking";
                    saveButton.style.visibility="hidden";
                    clearButton.style.visibility="hidden";
                    record=1;
            }
        }
       //This starts tracking
        else {
        //Changes button text and hides buttons
        trackButton.innerHTML="Stop Tracking";
        saveButton.style.visibility="hidden";
        clearButton.style.visibility="hidden";
            //Sets record to on
        record=1;
        }
    }
    
}


//This function handles all the makers that are needed on the map    
function setMarker() {
    
    //This section handles the current marker which moves to users current position to let the user know where they are on the map.
    if (currentMarker === undefined || currentMarker === null){
        currentMarker = new google.maps.Marker({
            position: currentCoordsGoogle,
            map: map,
            icon: 'http://www.clker.com/cliparts/e/w/T/q/9/L/running-icon-on-transparent-background-th.png',
            title: 'Current Position'
        });
    }
    else {
        currentMarker.setPosition(currentCoordsGoogle);
        
}
    
    //The start marker only appears if there is a route being tracked or if there is tracked route already in memory. It places a marker at the start position
    if (currentRouteGoogle.length>0){
    if (startMarker === undefined || startMarker === null){
        startMarker=new google.maps.Marker({
            position: currentRouteGoogle[0],
            map: map,
            animation: google.maps.Animation.DROP,
            title: 'Start Position'
        });
    }
    
    //The end marker only appears when tracking is off and there is a tracked route. It palces a marker at the end position
    if (record===0){
    if (endMarker === undefined || endMarker === null){    
            endMarker=new google.maps.Marker({
            position: currentRouteGoogle[currentRouteGoogle.length-1],
            map: map,
            animation: google.maps.Animation.DROP,    
            title: 'End Position'    
        });
    }

}
}
}

//This writes the polylines on the map which allows the user to see the path that they have taken
function writePath() {
    
    //It only writes path when tracking is enabled
    if (record===1){
    if (path === undefined || path === null){
    path = new google.maps.Polyline({
    path: currentRouteGoogle,
    geodesic: true,
    strokeColor: '#FF0000',
    strokeOpacity: 1.0,
    strokeWeight: 2,
    map:map
  });
    }
    else {
        path.setPath(currentRouteGoogle);
}
}
}
 
//This function calculates the current speed using two instantenous positions which is constantly updated.
function instantSpeed() {
    //Uses the calculate distance function to calculate distance between two points
    var instantDistance=calculateDistance(instantPosition[0].coords.longitude,instantPosition[0].coords.latitude,instantPosition[1].coords.longitude,instantPosition[1].coords.latitude);
    //Calculates time between the two points in hours
    instantTime= (instantPosition[1].timestamp - instantPosition[0].timestamp) / (1000*60*60);
    
    //Speed in km/h
    currentSpeed= (instantDistance/instantTime).toFixed(2);
        }
 
//This function calculates the distance of a tracked route 
function routeDistance() {
    //Two points are needed so it will only run if two points exist
    if (currentRoute.length>=2){
        totalDistance=0;
        //Calculates time by using the end points. The units are minutes
        timeTaken=(currentRoute[currentRoute.length-1].timestamp - currentRoute[0].timestamp)/ (1000*60); 
    //Goes through each position and uses adjacent points to calculate distance and adds it up to get total distance    
    for (i=0;i<(currentRoute.length -1);i++){
        //Utilizes the calculate distance function
        var distance= calculateDistance(currentRoute[i].coords.longitude,currentRoute[i].coords.latitude,currentRoute[i+1].coords.longitude,currentRoute[i+1].coords.latitude);
        //Calculates the total distance
        totalDistance=parseFloat(totalDistance)+parseFloat(distance);
         }
        //Calculates average speed in km/h
        avgSpeed=totalDistance/(timeTaken/60);
    }
}

//This function uses the haversine forumula to calculate the distance between two geographical locations
function calculateDistance(lon1, lat1, lon2, lat2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);  // deg2rad below
  var dLon = deg2rad(lon2-lon1); 
  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *  Math.sin(dLon/2) * Math.sin(dLon/2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c; // Distance in km
  return d;
}
//This function converts degrees to radians   
function deg2rad(deg) {
  return deg * (Math.PI/180)
}

//This function handles the writing of the on scrren display
function writeLabel(){
    
    //If a tracked route exists it changes the OSD to the following
    if (currentRoute.length>=2){
        document.getElementById("detailContainer").style.height="10%";  
        detailsLabel.innerHTML+="<br><br>";
        detailsLabel.innerHTML="Distance Travelled: " + parseFloat(totalDistance).toFixed(2) +" KM<br><br>";
        detailsLabel.innerHTML+= "Time Elasped:" + parseFloat(timeTaken).toFixed(2) +" Mins <br><br>";
        detailsLabel.innerHTML+= "Average Speed:" + parseFloat(avgSpeed).toFixed(2) +" KM/H <br><br>";
    }
    //If a tracked route does not exist it only shows current speed
    else{
        detailsLabel.innerHTML+="<br><br><br>";
        detailsLabel.innerHTML="Current Speed: " + currentSpeed + " KM/H";
    }
}

//This function checks if accuracy is below a certain threshold and disables traccking function if location is too inaccurate
function checkAccuracy(){
    
    //Only disables tracking if it is not tracking to avoid problems
    if (record===0){
    //The chosen threshold is 20 as after this value the locations seem to sway off the actual position and become innaccurate
    if (parseFloat(accuracy)>20){
        //Shows the accuracy to the user
        techLabel.innerHTML="Accuracy: " + parseFloat(accuracy).toFixed(2) + " (Accuracy too low.<br> Record Disabled)";
        trackButton.style.visibility="hidden";
    }
    else {
         techLabel.innerHTML="Accuracy: " + parseFloat(accuracy).toFixed(2) ;
         trackButton.style.visibility="visible";
        }
                                                                        
}
}
    
//This clears any tracked route that are in memory   
function clearRoute() {
    //Removes polylines and markers from map and sets it to null so that the if loops can be restarted if the user wishes to rerun
   path.setMap(null);
   path=null;
   startMarker.setMap(null);
   endMarker.setMap(null);
   startMarker=null;
   endMarker=null;
   currentRoute=[];
   currentRouteGoogle=[];  
}
        
 //This function handles the saving of a route to the local storage   
function save() {
    
    //Checks if local storage is avaiable
    if (typeof(Storage) !== "undefined"){
            console.log ("localStorage is available.");
        
        //If a tracked route exists
            if (currentRoute !== undefined || currentRoute !== null){
            if (currentRoute.length>0){
            //Gets date    
            var currentDate = new Date(); 
            var dateTime = currentDate.getDate() + "/"+ (currentDate.getMonth()+1)  + "/"+ currentDate.getFullYear();
            var name= prompt("Enter Save Name", currentDate.getDate() + "/"+ (currentDate.getMonth()+1)  + "/"+ currentDate.getFullYear());
			//Creates an object that contains all releavnt information for the view page
                var routeSave = {
                name:name.toLocaleString(), 
                dateCreated: dateTime.toLocaleString(), 
                routeDetails:currentRoute, 
                routeDetailsGoogle:currentRouteGoogle, 
                distance:parseFloat(totalDistance).toFixed(2), 
                timeTaken:parseFloat(timeTaken).toFixed(2), 
                avgSpeed: parseFloat(avgSpeed).toFixed(2)
                };
                
            //Converts object to string and stores in local storage
			var jsonRoute = JSON.stringify(routeSave);
			localStorage.setItem ("Route-"+ name, jsonRoute);
            
            //Changes colour of polyline to green to indicate path has been saved
            path.setOptions({strokeColor:'#008000'})
                }
            //If a tracked route does not exist    
                else {
            alert('Tracked Route does not exist');
            }
            }
            else {
            alert('Tracked Route does not exist');
            }
        }
    //If local storage is not supported
		else
		{
			console.log("Sorry! Your current browser does not support localStorage.");
		}
}
    