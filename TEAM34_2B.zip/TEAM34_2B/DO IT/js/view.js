//Global Variables
var map;
var startMarker;
var endMarker;
var path;
var routesSaved=[];
        
//Runs function that gets all the routes
getRoutes();


//This function is run when the user clicks on the view button next to a route. It initializes the map and displays all the polylines
//and markers associated with the selected route. The selected route is conveyred through the input variable i
function initialize(i) {
    
    //This code retrieves the specific item from local storage 
    var key = localStorage.key(i); 
    var savedRoute= localStorage.getItem(key);
    var data=JSON.parse(savedRoute);    
    
    //Converts each individual array item from string back into a number
    var routeDetails=convertString(data.routeDetailsGoogle);
    var lastVal=routeDetails.length-1;
    
    //Initialises google map in the map div
    map = new google.maps.Map(document.getElementById('map'), {
    zoom: 18
  });
    
    //Centers map on the start position
    map.panTo(routeDetails[0]);
    
    //Creates a marker object at the start position
    startMarker=new google.maps.Marker({
            position: routeDetails[0],
            map: map,
            animation: google.maps.Animation.DROP,
            icon: "http://maps.google.com/intl/en_us/mapfiles/ms/micons/green-dot.png",
            title: 'Start Position'
        });
    
    //Creates a marler pbkect at the end position
    endMarker=new google.maps.Marker({
            position: routeDetails[lastVal],
            map: map,
            animation: google.maps.Animation.DROP,
            icon: "http://maps.google.com/intl/en_us/mapfiles/ms/micons/red-dot.png",
            title: 'End Position'
        });
    
    //Draws polylines between the saved geographical positions
    path = new google.maps.Polyline({
    path: routeDetails,
    geodesic: true,
    strokeColor: '#FF0000',
    strokeOpacity: 1.0,
    strokeWeight: 2,
    map:map
  });
    
    
    }


function caloriesCount(speed, time){

	// this is only an estimate of the calories burned
	// Utlises the method used in treadmills

	// Units: speed (m/min), weight (kg), time (min), grade (%/100)

	var calories;
	var runType = ["quickstart", "walking", "running", "cycling"];
    
    speed = speed/60; //converts speed to m/min

	// We are assuming an average grade (slope) of 8% ~ slope of 5 degrees
	// as outdoor grounds are usually quite uneven, contains mild hills/slopes
	grade = 0.08;


	// calculating the grade 

	// convert mph to m/min by multiplying by 26.8
	

	if (runType = "quickstart"){

		//for quick start option, only running or walking and avaliable
		if (speed <= 3.7*26.8){
			// speed < 3.7 mph is walking speed
			calories = time*((0.1*speed) + (1.8*speed*grade) + 3.5);

		} else if (speed > 3.7*26.8){
			// speed > 3.7 mph is running speed
			calories = time*((0.2*speed) + (1.8*speed*grade) + 3.5);
        }

        } else if (runType = "walking"){
            calories = time*((0.1*speed) + (1.8*speed*grade) + 3.5);
        } else if (runType = "running"){
            calories = time*((0.2*speed) + (1.8*speed*grade) + 3.5);
        } else if (runType = "cycling"){
            calories = time*((0.03*speed) + (0.76*speed*grade) + 2);
        }
    

        return calories;
}


//This function gets all the routes from local storage and formats the relevant data of each route into a table.
function getRoutes(){
    
        //The following code runs only if there is any routes saved in local storage
        if (localStorage.length>0){
        
            //Creates the table headers
        var table="<table style='width:100%'><tr><th><button class='mdl-button mdl-js-button' onclick='sortName()'>Name</button></th><th>Date</th><th>Total Distance (KM)</th><th>Time Elasped (Mins)</th><th>Average Speed (KM/H)</th><th>Calories</th><th>Display</th><th>Clear</th></tr>";
            
            //Goes through all the routes in local storage one at a time
            for (i = 0; i < localStorage.length; i++) {
                
                //Retrieves route from local storage. 
                var key = localStorage.key(i); 
                var savedRoute= localStorage.getItem(key);
                var data=JSON.parse(savedRoute);
                var calories = caloriesCount(data.avgSpeed, data.timeTaken);
                
                //Formats the data into a table. It also adds a display and clear button to each row. Note that the onclick for button uses the i value. This is essential for the initialise function as it tells the function which map to write
                table+="<tr><td>"+data.name+"</td><td>"+data.dateCreated+"</td><td>"+data.distance+"</td><td>"+data.timeTaken+"</td><td>"+data.avgSpeed+"</td><td>"+Number(calories).toFixed(2)+"</td>";
                table+="<td><button id="+i+" button class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored'  onclick = 'openBox("+i+")'>Display</button></td>";
                table+="<td><button id="+i+" button class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'  onclick = 'clearRoute("+i+")'>Clear</button></td>";
                                                                                                                             
            }
        //Closes the table     
        table+="</table><br>"; 
            
        // Adds a clear all button   
        table+="<center><button id='clearRoutes' button class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'  onclick = 'clearAllRoutes()'>Clear All</button><br><br>";
            
        //Writes the data to the table div    
        document.getElementById('table').innerHTML = table; 
    }
        else {
        //This code is run if there are no saved routes
        document.getElementById('noSave').innerHTML="No saved Routes detected";
    }
}
      
//This function converts string into a number    
function convertString(routeDetailsGoogle){
        
        var lastVal=routeDetailsGoogle.length-1;
        var routeDetails=[];
        
        //Goes through each item and converts it to a number and then into a google latitude longitude object
        for (i=0;i<lastVal;i++){
            var lat= parseFloat(routeDetailsGoogle[i].G);
            var lon= parseFloat(routeDetailsGoogle[i].K);
            var latLon= new google.maps.LatLng(lat,lon);
            routeDetails.push(latLon);
        }
        
        return routeDetails;
        
        
    }

//Closes the div box
function closeBox() {
    
    document.getElementById('light').style.display='none';
    document.getElementById('fade').style.display='none'; 
    
}
    
    
//Clears a specific route as specificed by the input variable i    
function clearRoute(i) {
        var key = localStorage.key(i); 
        localStorage.removeItem(key);
        location.reload();
}

//Opens the div box and runs initialize 
function openBox(i) {
        
        document.getElementById('light').style.display='block';
        document.getElementById('fade').style.display='block'; 
        
        
        initialize(i);
        
}

//Clears all of the routes
function clearAllRoutes() {
    localStorage.clear();
    location.reload();
}


