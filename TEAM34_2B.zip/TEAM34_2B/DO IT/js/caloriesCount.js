

function caloriesCount(speed, time){

	// this is only an estimate of the calories burned
	// Utlises the method used in treadmills

	// Units: speed (m/min), weight (kg), time (min), grade (%/100)

	var calories;
	var runType = ["quickstart", "walking", "running", "cycling"];

	// We are assuming an average grade (slope) of 8% ~ slope of 5 degrees
	// as outdoor grounds are usually quite uneven, contains mild hills/slopes
	grade = 0.08;
    runType = runType[0];


	// calculating the grade 

	// convert mph to m/min by multiplying by 26.8
	

	if (runType = "quickstart"){

		//for quick start option, only running or walking and avaliable
		if (speed <= 3.7*26.8){
			// speed < 3.7 mph is walking speed
			calories = (0.1*speed) + (1.8*speed*grade) + 3.5;

		} else if (speed > 3.7*26.8){
			// speed > 3.7 mph is running speed
			calories = (0.2*speed) + (1.8*speed*grade) + 3.5;
        }

        } else if (runType = "walking"){
            calories = (0.1*speed) + (1.8*speed*grade) + 3.5;
        } else if (runType = "running"){
            calories = (0.2*speed) + (1.8*speed*grade) + 3.5;
        }

        return calories;
}


function calculate(speed, time){
    //This function calculates the 
    var Speed = speed*1000/60;
    var time;
    var weight = 65;
    
    if (runType = "quickstart"){
        weight = 65;
    }
    else{
        weight = JSON.parse(localStorage.getItem("details")).Weight;
    }

   return caloriesCount(Speed, time);
    
}

