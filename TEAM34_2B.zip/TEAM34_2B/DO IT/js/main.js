function check(form){
    //function to check userid & password
    //the following code checkes whether the entered userid and password are matching
    if(form.userid.value == "team34" && form.pswrd.value == "12345676"){
        window.location.href="#home"//directs user to home page if user & pw mathces
    }

    else{
        alert("Error! Incorrect Password or Username") //displays error message
    }
}


function addTOSettings(){
    //the following code checkes whether the entered userid and password are matching
    var name = document.getElementById("name").value;
    var weight = document.getElementById("weight").value;
    var settings = {Name: name, Weight: weight};
    console.log(settings);
    
    var settingsStorage = JSON.stringify(settings);
    localStorage.setItem("details", settingsStorage);
    
}


function colourAid(){
    //This function changes the colour settings so that the colours are more suited for colourblind people
    var oldCSS = document.getElementById("theme");
    
    if (oldCSS.href=="css/main.css"){
        oldCSS.setAttribute("href","css/colourBlind.css");
    }
    else{
        oldCSS.setAttribute("href","css/main.css");
    }
}

// The following functions trigger the alert windows that appear when HELP is clicked on each page
function popUP_Home() {
    //Pop up window that displays instructions when "HELP" Button is clicked
    var message;
        message = "Select QuickStart to start running or walking. Your weight will be set to default weight, calories include running/walking. Select NEW RUN to manually select a run type. Saved Runs will let you view your previous saved runs.";     
    alert(message);
}


function popUP_runType() {
    //Pop up window that displays instructions when "HELP" Button is clicked
    var message;
    message ="Select a Run Type. Enter your name, Enter your weight, Press the plus button to save your details, Then Press Start to begin, Goodluck!";
    alert(message);
}


function popUP_view() {
    //Pop up window that displays instructions when "HELP" Button is clicked
    var message;
    message = "This displays the list of your runs with their details. To view each route, simply click DISPLAY. To Delete a route, simple click CLEAR. Clicking CLEAR ALL will instantly clear all routes!";
    alert(message);
}


function popUP_track() {
    //Pop up window that displays instructions when "HELP" Button is clicked
    var message;
        message = "When location accuracy is below 20, you will be able to select START TRACKING to track your routes. You are the stick figure! He will show you your path! Save route or Clear. Goodluck!";     
    alert(message);
}


